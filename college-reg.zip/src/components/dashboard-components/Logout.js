import React from "react";

const Logout = () => {
  return <h1>LLogout Page</h1>;
};

export default Logout;