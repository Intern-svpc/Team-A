import React from "react";

function StudentModal({ isOpen, onClose, title, students }) {
  return (
    <>
      <div className={`overlay ${isOpen ? "overlay-open" : ""}`} onClick={onClose}></div>
      <div className={`modal ${isOpen ? "modal-open" : ""}`}>
        <div className="modal-content">
          <h2>{title}</h2>
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Roll No</th>
                  <th>Attempted</th>
                  <th>Submit Status</th>
                  <th>Submitted At</th>
                  <th>Restart</th>
                </tr>
              </thead>
              <tbody>
                {students.map((student, index) => (
                  <tr key={index}>
                    <td>{student.name}</td>
                    <td>{student.roll_no}</td>
                    <td>{student.attempted}</td>
                    <td>{student.submitted}</td>
                    <td>{student.timestamp}</td>
                    <td><button>Restart</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <button onClick={onClose}>Close</button>
        </div>
      </div>
    </>
  );
}
export default StudentModal;