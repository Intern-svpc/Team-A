import React from "react";

function ExpiredLinksTable({ expiredLinks }) {
  return (
    <><h2>Expired Links</h2>
    <table>
        
      <thead>
        <tr>
          <th>College Name</th>
          <th>Branch</th>
          <th>URL</th>
          <th>Students Attempted</th>
          <th>Students Submitted</th>
          <th>Time of Expiry</th>
        </tr>
      </thead>
      <tbody>
        {expiredLinks.length > 0 ? (
          expiredLinks.map((item, index) => (
            <tr key={index}>
              <td>{item.collegeName || "N/A"}</td>
              <td>{item.branch || "N/A"}</td>
              <td>{item.url || "N/A"}</td>
              <td>{item.numStudentsAttempted || 0}</td>
              <td>{item.numStudentsSubmitted || 0}</td>
              <td>{new Date(item.timeOfUrlExpiry).toLocaleString()}</td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan="6">No expired links found</td>
          </tr>
        )}
      </tbody>
    </table>
    </>
    
  );
}

export default ExpiredLinksTable;
