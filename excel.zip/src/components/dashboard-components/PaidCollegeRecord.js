import React from "react";

const PaidCollegeRecord = () => {
  return <h1>Dashboard Page</h1>;
};

export default PaidCollegeRecord;