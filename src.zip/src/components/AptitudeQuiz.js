import React, { useEffect, useState } from "react";
import "./AptitudeQuiz.css";
const AptitudeQuiz = () => {
    const [questions, setQuestions] = useState([]); 
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [selectedOptions, setSelectedOptions] = useState({});
    const [markedQuestions, setMarkedQuestions] = useState([]);
    const [timeLeft, setTimeLeft] = useState(180);
    const [score, setScore] = useState(null);
    const [review, setReview] = useState([]);
    const [loading, setLoading] = useState(true);
    const [quizSubmitted, setQuizSubmitted] = useState(false);

    useEffect(() => {
        fetchQuestions();
    }, []);

    useEffect(() => {
        if (timeLeft <= 0) {
            submitQuiz();
            return;
        }

        if (quizSubmitted) return; // Stop timer after submission

        const timer = setInterval(() => {
            setTimeLeft(prev => prev - 1);
        }, 1000);

        return () => clearInterval(timer);
    }, [timeLeft, quizSubmitted]);

    async function fetchQuestions() {
        try {
            const response = await fetch("http://localhost:5000/api/questions");
            const data = await response.json();
            setQuestions(data || []); 
        } catch (error) {
            console.error("Error fetching questions:", error);
            setQuestions([]);
        } finally {
            setLoading(false);
        }
    }

    function selectOption(index) {
        setSelectedOptions(prev => ({
            ...prev,
            [currentQuestion]: index
        }));
    }

    function toggleMarkQuestion() {
        setMarkedQuestions(prev =>
            prev.includes(currentQuestion)
                ? prev.filter(q => q !== currentQuestion)
                : [...prev, currentQuestion]
        );
    }

    function nextQuestion() {
        if (currentQuestion < questions.length - 1) setCurrentQuestion(prev => prev + 1);
    }

    function prevQuestion() {
        if (currentQuestion > 0) setCurrentQuestion(prev => prev - 1);
    }

    async function submitQuiz() {
        if (quizSubmitted) return; // Prevent duplicate submissions

        setQuizSubmitted(true); // Mark quiz as submitted

        try {
            const response = await fetch("http://localhost:5000/api/submit", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ userResponses: selectedOptions })
            });

            const data = await response.json();
            setScore(data.score);
            setReview(data.review);
        } catch (error) {
            console.error("Error submitting quiz:", error);
        }
    }

    if (loading) return <h2>Loading...</h2>;
    if (!questions.length) return <h2>No questions available.</h2>;

    return (
        <div className="quiz-container">
            <div className="header">
                <div className="timer">{`${Math.floor(timeLeft / 60)}:${(timeLeft % 60).toString().padStart(2, '0')}`}</div>
                <h2>Aptitude Quiz</h2>
            </div>

            {score === null ? (
                <>
                    <h3>
                        {questions[currentQuestion]?.question || "Loading question..."}
                        {markedQuestions.includes(currentQuestion) && <span> ⭐ (Marked for Review)</span>}
                    </h3>
                    <div className="options">
                        {questions[currentQuestion]?.options?.map((opt, i) => (
                            <button
                                key={i}
                                className={selectedOptions[currentQuestion] === i ? "selected" : ""}
                                onClick={() => selectOption(i)}
                            >
                                {opt}
                            </button>
                        ))}
                    </div>
                    <div className="nav-buttons">
                        <button onClick={prevQuestion} disabled={currentQuestion === 0}>Previous</button>
                        <button onClick={toggleMarkQuestion}>
                            {markedQuestions.includes(currentQuestion) ? "Unmark" : "Mark for Review"}
                        </button>
                        <button onClick={nextQuestion} disabled={currentQuestion === questions.length - 1}>Next</button>
                        <button onClick={submitQuiz}>Submit</button>
                    </div>
                </>
            ) : (
                <div className="result-section">
                    <h2>Quiz Result</h2>
                    <p>Score: {score} / {questions.length}</p>
                    <h3>Review:</h3>
                    <ul>
                        {review.map((r, i) => (
                            <li key={i}>
                                <b>Q:</b> {questions[i].question} <br />
                                <b>Selected:</b> {r.selected !== undefined ? questions[i].options[r.selected] : "None"} <br />
                                <b>Correct:</b> {questions[i].options[r.correct]} <br />
                                <b>{r.isCorrect ? "✔ Correct" : "❌ Incorrect"}</b>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default AptitudeQuiz;
