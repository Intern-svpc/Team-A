import React from "react";

const CollegeRecord = () => {
  return <h1>Dashboard Page</h1>;
};

export default CollegeRecord;